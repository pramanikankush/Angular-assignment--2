export interface Product {
  pid: string;
  pname: string;
  price: number;
  category: string;
}
